const axios = require('axios');

exports.handler = (event, context, callback) => {
  const postObject = JSON.stringify({
    client_id: 'N8mZqxROKp4jgs5ZuQZg8F8oZcYPZq8w',
    client_secret:
      'co3NvXvMA7DofOUwBE9B5HVedcdjx9ZRnJ2d64am0g8aIAbO81vPEDV9cU8okXs0',
    audience: 'https://reubenellis.auth0.com/api/v2/',
    grant_type: 'client_credentials',
  });
  const url = `https://reubenellis.auth0.com/oauth/token`;
  const options = {
    body: postObject,
    headers: {
      'Content-Type': 'application/json',
    },
  };
  axios.post(url, options).then((res) => {
    console.log(res);
  });
};
